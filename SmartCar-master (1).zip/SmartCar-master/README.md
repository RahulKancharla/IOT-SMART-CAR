# SmartCar

ExtraOrdinary than ordinary car

A Car which can ensures safety.

The main components used are

1) MQ135 Gas Sensor which helps us to find how much carbondioxide the vehicle is releasing

2) HC-SR04 Distance sensor which helps us in calculating distance between your car and the car ahead of you and gives a warning if you are too close to it.

3) ADXL335 Accelerometrer if you vehicle is in the same position for a long time it stops the engine to save fuel.

4) NodeMCU for connection of all components.

5) ThingSpeak account for connection of components to mobile app.

Note:- Don't forget to install WIFI Drivers in NodeMCU
